
About my code

- I have reused the code provided in hus.HusBoardState. 

- My code uses the classes in the mytools package

- I have 3 extra classes in mytools package
	- Strategy.java 
	- PackagePit.java
	- MyTools.java


- Strategy.java uses Package.java 

- MyTools.java is used by StudentPlayer
	
- I wrote comments in my code

